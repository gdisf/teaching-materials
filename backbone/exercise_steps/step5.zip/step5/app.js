new ChatRouter();
Backbone.history.start({pushState: true});