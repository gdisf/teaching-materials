describe("define a global variable called areGirlDevelopersCool", function() {
    it("and set it to true", function() {
	    expect(areGirlDevelopersCool).toBeDefined();
	    expect(areGirlDevelopersCool).toEqual(true);
	});
});
